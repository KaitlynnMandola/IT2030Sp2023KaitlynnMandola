﻿using Microsoft.AspNetCore.Mvc;

namespace KaitlynnKeyboardsAndKilobytes.Controllers
{
    public class ContactController : Controller
    {
        public IActionResult Index()
        {
            ViewBag.FV = 0;
            return View();
        }

        public IActionResult Index(ContactModel model)
        {
            ViewBag.FV = model.ContactModel();
            return View(model);
        }
    }
}
