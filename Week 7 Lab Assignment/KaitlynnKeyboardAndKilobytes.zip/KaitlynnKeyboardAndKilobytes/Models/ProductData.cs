﻿namespace KaitlynnKeyboardsAndKilobytes.Models
{
    public class ProductData
    {
        public static List<ProductModel> GetProducts()
        {
            List<ProductModel> products = new List<ProductModel>
            {
                new ProductModel
                {
                    ProductId = 1,
                    ProductName = "Wireless Keyboard",
                    ProductDescription = "Keyboard",
                    ProductImage = "wireless-keyboard.jpg",
                    ProductPrice = 50
                },
                new ProductModel
                {
                    ProductId = 2,
                    ProductName = "Mechanical Keyboard",
                    ProductDescription = "Keyboard",
                    ProductImage = "mechanical-keyboard.jpg",
                    ProductPrice = 110
                },
                new ProductModel
                {
                    ProductId = 3,
                    ProductName = "Internal SSD",
                    ProductDescription = "Solid State Drive",
                    ProductImage = "internal-ssd.jpg",
                    ProductPrice = 170
                },
                new ProductModel
                {
                    ProductId = 4,
                    ProductName = "External SSD",
                    ProductDescription = "Solid State Drive",
                    ProductImage = "external-ssd.jpg",
                    ProductPrice = 90
                },
                new ProductModel
                {
                    ProductId = 5,
                    ProductName = "Internal Hard Drive",
                    ProductDescription = "Hard Drive",
                    ProductImage = "internal-hd.jpg",
                    ProductPrice = 200
                },
                new ProductModel
                {
                    ProductId = 6,
                    ProductName = "External Hard Drive",
                    ProductDescription = "Hard Drive",
                    ProductImage = "external-hd.jpg",
                    ProductPrice = 100
                }
            };

            return products;
        }

        public static ProductModel GetProduct(int id)
        {
            List<ProductModel> products = ProductData.GetProducts();
            foreach (ProductModel product in products)
            {
                if (product.ProductId == id)
                {
                    return product;
                }
            }
            return new ProductModel();
        }
    }
}
