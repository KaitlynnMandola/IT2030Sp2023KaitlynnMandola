﻿namespace KaitlynnKeyboardsAndKilobytes.Models
{
    public class MySession
    {
        public string FirstName { get; set; } = string.Empty;

        public string LastName { get; set; } = string.Empty;

        public string Course { get; set; } = string.Empty;

        public int FavNum { get; set; }
    }
}
