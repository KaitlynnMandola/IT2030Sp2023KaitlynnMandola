﻿using System.ComponentModel.DataAnnotations;

namespace KaitlynnKeyboardsAndKilobytes.Models
{
    public class ContactModel
    {
        [Required(ErrorMessage = "Please enter your first name.")]
        [StringLength(30, ErrorMessage = "First name cannot be more than 30 characters.")]
        [RegularExpression(@"^[a-zA-Z''-'\s]{1,30}$", ErrorMessage = "First name cannot contain special characters or numbers.")]
        public string FirstName { get; set; }

        [Required(ErrorMessage = "Please enter your last name.")]
        [StringLength(30, ErrorMessage = "Last name cannot be more than 30 characters.")]
        [RegularExpression(@"^[a-zA-Z''-'\s]{1,30}$", ErrorMessage = "Last name cannot contain special characters or numbers.")]
        public string LastName { get; set; }

        [Required(ErrorMessage = "Please enter your address.")]
        public string Address { get; set; }

        [Required(ErrorMessage = "Please enter your phone number.")]
        [RegularExpression(@"^[0-9]{10}$", ErrorMessage = "Phone number must be 10 digits and numbers only.")]
        public string Phone { get; set; }

        [Required(ErrorMessage = "Please enter your email address")]
        [EmailAddress(ErrorMessage = "Invalid email address.")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Please enter your message for us.")]
        public string Message { get; set; }
        

    }
}
